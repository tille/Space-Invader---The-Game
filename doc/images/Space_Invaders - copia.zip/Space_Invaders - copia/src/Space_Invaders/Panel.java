package Space_Invaders;

public class Panel extends javax.swing.JPanel
{
    private Juego juego;
    private int nNave=0;
    Panel(Juego juego)
    {
        initComponents();
        this.juego = juego;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jFormattedTextField1 = new javax.swing.JFormattedTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel11 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jFormattedTextField2 = new javax.swing.JFormattedTextField();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jTextArea2 = new javax.swing.JTextArea();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        velocidad = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        poder = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        disparo = new javax.swing.JLabel();

        setBackground(new java.awt.Color(0, 0, 0));
        setMaximumSize(null);
        setPreferredSize(new java.awt.Dimension(700, 70));
        setLayout(null);

        jLabel1.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 204, 0));
        jLabel1.setText("Nombre");
        jLabel1.setFocusable(false);
        add(jLabel1);
        jLabel1.setBounds(580, 600, 60, 20);

        jFormattedTextField1.setBackground(new java.awt.Color(0, 0, 0));
        jFormattedTextField1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jFormattedTextField1.setForeground(new java.awt.Color(51, 204, 0));
        jFormattedTextField1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14));
        jFormattedTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFormattedTextField1ActionPerformed(evt);
            }
        });
        add(jFormattedTextField1);
        jFormattedTextField1.setBounds(660, 600, 539, 22);

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(51, 204, 0));
        jButton1.setText("JUGAR");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton1.setContentAreaFilled(false);
        jButton1.setFocusPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        add(jButton1);
        jButton1.setBounds(1240, 600, 87, 22);

        jButton2.setBackground(new java.awt.Color(0, 0, 0));
        jButton2.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton2.setForeground(new java.awt.Color(51, 204, 0));
        jButton2.setText("Capitan");
        jButton2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton2.setContentAreaFilled(false);
        jButton2.setFocusPainted(false);
        add(jButton2);
        jButton2.setBounds(240, 600, 116, 22);

        jButton3.setBackground(new java.awt.Color(0, 0, 0));
        jButton3.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton3.setForeground(new java.awt.Color(51, 204, 0));
        jButton3.setText("Cerrar");
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton3.setContentAreaFilled(false);
        jButton3.setFocusPainted(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        add(jButton3);
        jButton3.setBounds(110, 600, 116, 22);

        jButton4.setBackground(new java.awt.Color(0, 0, 0));
        jButton4.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(51, 204, 0));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Space_Invaders/Imagenes/nave1Inicio.png"))); // NOI18N
        jButton4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton4.setContentAreaFilled(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        add(jButton4);
        jButton4.setBounds(660, 130, 116, 131);

        jButton5.setBackground(new java.awt.Color(0, 0, 0));
        jButton5.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton5.setForeground(new java.awt.Color(51, 204, 0));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Space_Invaders/Imagenes/nave3Inicio.png"))); // NOI18N
        jButton5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton5.setContentAreaFilled(false);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        add(jButton5);
        jButton5.setBounds(1100, 130, 116, 131);

        jButton6.setBackground(new java.awt.Color(0, 0, 0));
        jButton6.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton6.setForeground(new java.awt.Color(51, 204, 0));
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Space_Invaders/Imagenes/nave2Inicio.png"))); // NOI18N
        jButton6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton6.setContentAreaFilled(false);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        add(jButton6);
        jButton6.setBounds(880, 130, 116, 131);

        jLabel2.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 204, 0));
        jLabel2.setText("ELIGE TU VEHICULO DE COMBATE");
        jLabel2.setFocusable(false);
        add(jLabel2);
        jLabel2.setBounds(810, 60, 224, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 204, 0));
        jLabel4.setText("     Start TX-300");
        jLabel4.setFocusable(false);
        add(jLabel4);
        jLabel4.setBounds(880, 280, 117, 20);

        jButton7.setBackground(new java.awt.Color(0, 0, 0));
        jButton7.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton7.setForeground(new java.awt.Color(51, 204, 0));
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Space_Invaders/Imagenes/nave1Inicio.png"))); // NOI18N
        jButton7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton7.setContentAreaFilled(false);
        add(jButton7);
        jButton7.setBounds(660, 130, 116, 131);

        jButton8.setBackground(new java.awt.Color(0, 0, 0));
        jButton8.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton8.setForeground(new java.awt.Color(51, 204, 0));
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Space_Invaders/Imagenes/nave3Inicio.png"))); // NOI18N
        jButton8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton8.setContentAreaFilled(false);
        add(jButton8);
        jButton8.setBounds(1100, 130, 116, 131);

        jButton9.setBackground(new java.awt.Color(0, 0, 0));
        jButton9.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton9.setForeground(new java.awt.Color(51, 204, 0));
        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Space_Invaders/Imagenes/nave2Inicio.png"))); // NOI18N
        jButton9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton9.setContentAreaFilled(false);
        add(jButton9);
        jButton9.setBounds(880, 130, 116, 131);

        jLabel6.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 204, 0));
        jLabel6.setText("ELIGE TU VEHICULO DE COMBATE");
        jLabel6.setFocusable(false);
        add(jLabel6);
        jLabel6.setBounds(810, 60, 224, 20);

        jLabel8.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 204, 0));
        jLabel8.setText("     Start TX-300");
        jLabel8.setFocusable(false);
        add(jLabel8);
        jLabel8.setBounds(880, 280, 117, 20);

        jLabel9.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 204, 0));
        jLabel9.setText("    Storm STY-A2");
        jLabel9.setFocusable(false);
        add(jLabel9);
        jLabel9.setBounds(1100, 280, 117, 20);

        jLabel10.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 204, 0));
        jLabel10.setText("  Falcon XFG-321");
        jLabel10.setFocusable(false);
        add(jLabel10);
        jLabel10.setBounds(660, 280, 117, 20);

        jTextArea1.setBackground(new java.awt.Color(0, 0, 0));
        jTextArea1.setColumns(20);
        jTextArea1.setEditable(false);
        jTextArea1.setFont(new java.awt.Font("Monospaced", 1, 15)); // NOI18N
        jTextArea1.setForeground(new java.awt.Color(51, 153, 0));
        jTextArea1.setRows(5);
        jTextArea1.setText("\n    \n      Mision Invasores Espaciales:\n\n      Tu mision si decides aceptarla es la\n\n      de salvar la tierra de los malvados\n\n      invasores que intentan tomar sus\n\n      recursos.\n\n      Eres la ultima esperanza de la  tierra.\n\n      Pero no temas has sido por ser el mejor\n\n      y como el mejor  podras elegir el mejor\n\n      vehiculo de combate.       \n\n      Recuerda la tierra depende de TI. \n\n\n      Cambio y fuera.");
        jTextArea1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        add(jTextArea1);
        jTextArea1.setBounds(60, 30, 450, 550);

        jLabel11.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 204, 0));
        jLabel11.setText("  Falcon XFG-321");
        jLabel11.setFocusable(false);
        add(jLabel11);
        jLabel11.setBounds(660, 280, 117, 20);

        jLabel14.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 204, 0));
        jLabel14.setText("    Storm STY-A2");
        jLabel14.setFocusable(false);
        add(jLabel14);
        jLabel14.setBounds(1100, 280, 117, 20);

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setMaximumSize(null);
        jPanel1.setPreferredSize(new java.awt.Dimension(700, 70));
        jPanel1.setLayout(null);

        jLabel3.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 204, 0));
        jLabel3.setText("Nombre");
        jLabel3.setFocusable(false);
        jPanel1.add(jLabel3);
        jLabel3.setBounds(580, 600, 60, 20);

        jFormattedTextField2.setBackground(new java.awt.Color(0, 0, 0));
        jFormattedTextField2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jFormattedTextField2.setForeground(new java.awt.Color(51, 204, 0));
        jFormattedTextField2.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14));
        jPanel1.add(jFormattedTextField2);
        jFormattedTextField2.setBounds(660, 600, 539, 22);

        jButton10.setBackground(new java.awt.Color(0, 0, 0));
        jButton10.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton10.setForeground(new java.awt.Color(51, 204, 0));
        jButton10.setText("JUGAR");
        jButton10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton10.setContentAreaFilled(false);
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton10);
        jButton10.setBounds(1240, 600, 87, 23);

        jButton11.setBackground(new java.awt.Color(0, 0, 0));
        jButton11.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton11.setForeground(new java.awt.Color(51, 204, 0));
        jButton11.setText("Capitan");
        jButton11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton11.setContentAreaFilled(false);
        jPanel1.add(jButton11);
        jButton11.setBounds(240, 600, 116, 23);

        jButton12.setBackground(new java.awt.Color(0, 0, 0));
        jButton12.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton12.setForeground(new java.awt.Color(51, 204, 0));
        jButton12.setText("Cerrar");
        jButton12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton12.setContentAreaFilled(false);
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton12);
        jButton12.setBounds(110, 600, 116, 23);

        jButton13.setBackground(new java.awt.Color(0, 0, 0));
        jButton13.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton13.setForeground(new java.awt.Color(51, 204, 0));
        jButton13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Space_Invaders/Imagenes/nave1Inicio.png"))); // NOI18N
        jButton13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton13.setContentAreaFilled(false);
        jPanel1.add(jButton13);
        jButton13.setBounds(660, 130, 116, 131);

        jButton14.setBackground(new java.awt.Color(0, 0, 0));
        jButton14.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton14.setForeground(new java.awt.Color(51, 204, 0));
        jButton14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Space_Invaders/Imagenes/nave3Inicio.png"))); // NOI18N
        jButton14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton14.setContentAreaFilled(false);
        jPanel1.add(jButton14);
        jButton14.setBounds(1100, 130, 116, 131);

        jButton15.setBackground(new java.awt.Color(0, 0, 0));
        jButton15.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton15.setForeground(new java.awt.Color(51, 204, 0));
        jButton15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Space_Invaders/Imagenes/nave2Inicio.png"))); // NOI18N
        jButton15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton15.setContentAreaFilled(false);
        jPanel1.add(jButton15);
        jButton15.setBounds(880, 130, 116, 131);

        jLabel16.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 204, 0));
        jLabel16.setText("ELIGE TU VEHICULO DE COMBATE");
        jLabel16.setFocusable(false);
        jPanel1.add(jLabel16);
        jLabel16.setBounds(810, 60, 224, 20);

        jLabel17.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 204, 0));
        jLabel17.setText("     Start TX-300");
        jLabel17.setFocusable(false);
        jPanel1.add(jLabel17);
        jLabel17.setBounds(880, 280, 117, 20);

        jLabel18.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 204, 0));
        jLabel18.setText("    Storm STY-A2");
        jLabel18.setFocusable(false);
        jPanel1.add(jLabel18);
        jLabel18.setBounds(760, 430, 117, 20);

        jButton16.setBackground(new java.awt.Color(0, 0, 0));
        jButton16.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton16.setForeground(new java.awt.Color(51, 204, 0));
        jButton16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Space_Invaders/Imagenes/nave1Inicio.png"))); // NOI18N
        jButton16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton16.setContentAreaFilled(false);
        jPanel1.add(jButton16);
        jButton16.setBounds(660, 130, 116, 131);

        jButton17.setBackground(new java.awt.Color(0, 0, 0));
        jButton17.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton17.setForeground(new java.awt.Color(51, 204, 0));
        jButton17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Space_Invaders/Imagenes/nave3Inicio.png"))); // NOI18N
        jButton17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton17.setContentAreaFilled(false);
        jPanel1.add(jButton17);
        jButton17.setBounds(1100, 130, 116, 131);

        jButton18.setBackground(new java.awt.Color(0, 0, 0));
        jButton18.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jButton18.setForeground(new java.awt.Color(51, 204, 0));
        jButton18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Space_Invaders/Imagenes/nave2Inicio.png"))); // NOI18N
        jButton18.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jButton18.setContentAreaFilled(false);
        jPanel1.add(jButton18);
        jButton18.setBounds(880, 130, 116, 131);

        jLabel19.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 204, 0));
        jLabel19.setText("ELIGE TU VEHICULO DE COMBATE");
        jLabel19.setFocusable(false);
        jPanel1.add(jLabel19);
        jLabel19.setBounds(810, 60, 224, 20);

        jLabel20.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 204, 0));
        jLabel20.setText("Poder");
        jLabel20.setFocusable(false);
        jPanel1.add(jLabel20);
        jLabel20.setBounds(590, 430, 117, 20);

        jLabel21.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 204, 0));
        jLabel21.setText("     Start TX-300");
        jLabel21.setFocusable(false);
        jPanel1.add(jLabel21);
        jLabel21.setBounds(880, 280, 117, 20);

        jLabel22.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 204, 0));
        jLabel22.setText("    Storm STY-A2");
        jLabel22.setFocusable(false);
        jPanel1.add(jLabel22);
        jLabel22.setBounds(1100, 280, 117, 20);

        jLabel23.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(0, 204, 0));
        jLabel23.setText("  Falcon XFG-321");
        jLabel23.setFocusable(false);
        jPanel1.add(jLabel23);
        jLabel23.setBounds(660, 280, 117, 20);

        jTextArea2.setBackground(new java.awt.Color(0, 0, 0));
        jTextArea2.setColumns(20);
        jTextArea2.setEditable(false);
        jTextArea2.setFont(new java.awt.Font("Monospaced", 1, 15)); // NOI18N
        jTextArea2.setForeground(new java.awt.Color(51, 153, 0));
        jTextArea2.setRows(5);
        jTextArea2.setText("\n    \n      Mision Invasores Espaciales:\n\n      Tu mision si decides aceptarla es la\n\n      de salvar la tierra de los malvados\n\n      invasores que intentan tomar sus\n\n      recursos.\n\n      Eres la ultima esperanza de la  tierra.\n\n      Pero no temas has sido por ser el mejor\n\n      y como el mejor  podras elegir el mejor\n\n      vehiculo de combate.       \n\n      Recuerda la tierra depende de TI. \n\n\n      Cambio y fuera.");
        jTextArea2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 204, 0)));
        jPanel1.add(jTextArea2);
        jTextArea2.setBounds(60, 30, 450, 550);

        jLabel24.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(0, 204, 0));
        jLabel24.setText("  Falcon XFG-321");
        jLabel24.setFocusable(false);
        jPanel1.add(jLabel24);
        jLabel24.setBounds(660, 280, 117, 20);

        jLabel25.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(0, 204, 0));
        jLabel25.setText("Velocidad Disparo");
        jLabel25.setFocusable(false);
        jPanel1.add(jLabel25);
        jLabel25.setBounds(590, 480, 117, 20);

        jLabel26.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(0, 204, 0));
        jLabel26.setText("Velocidad");
        jLabel26.setFocusable(false);
        jPanel1.add(jLabel26);
        jLabel26.setBounds(590, 380, 117, 20);

        jLabel27.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(0, 204, 0));
        jLabel27.setText("    Storm STY-A2");
        jLabel27.setFocusable(false);
        jPanel1.add(jLabel27);
        jLabel27.setBounds(1100, 280, 117, 20);

        jLabel28.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(0, 204, 0));
        jLabel28.setText("    Storm STY-A2");
        jLabel28.setFocusable(false);
        jPanel1.add(jLabel28);
        jLabel28.setBounds(760, 380, 117, 20);

        add(jPanel1);
        jPanel1.setBounds(0, 0, 700, 70);

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Estado", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("SimSun", 1, 18), new java.awt.Color(51, 204, 0))); // NOI18N
        jPanel2.setFocusable(false);
        jPanel2.setFont(new java.awt.Font("SimSun-ExtB", 1, 14)); // NOI18N

        jLabel15.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 204, 0));
        jLabel15.setText("Velocidad");
        jLabel15.setFocusable(false);

        velocidad.setFont(new java.awt.Font("MS Reference Specialty", 1, 14)); // NOI18N
        velocidad.setForeground(new java.awt.Color(0, 204, 0));
        velocidad.setText("I I I I I I I I I I");
        velocidad.setFocusable(false);

        jLabel7.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 204, 0));
        jLabel7.setText("Poder");
        jLabel7.setFocusable(false);

        poder.setFont(new java.awt.Font("MS Reference Specialty", 1, 14)); // NOI18N
        poder.setForeground(new java.awt.Color(0, 204, 0));
        poder.setText("I I I I I");
        poder.setFocusable(false);

        jLabel12.setFont(new java.awt.Font("Segoe UI Symbol", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 204, 0));
        jLabel12.setText("Velocidad Disparo");
        jLabel12.setFocusable(false);

        disparo.setFont(new java.awt.Font("MS Reference Specialty", 1, 14)); // NOI18N
        disparo.setForeground(new java.awt.Color(0, 204, 0));
        disparo.setText("I I I I I I I");
        disparo.setFocusable(false);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 138, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(disparo, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(velocidad, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(poder, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(velocidad))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(poder, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(disparo))
                .addContainerGap(40, Short.MAX_VALUE))
        );

        add(jPanel2);
        jPanel2.setBounds(680, 340, 550, 200);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        iniciarJuego();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        exit();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        setNNave(0);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        setNNave(1);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        setNNave(2);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jFormattedTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFormattedTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jFormattedTextField1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel disparo;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JFormattedTextField jFormattedTextField1;
    private javax.swing.JFormattedTextField jFormattedTextField2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JLabel poder;
    private javax.swing.JLabel velocidad;
    // End of variables declaration//GEN-END:variables

    private void exit()
    {
        System.exit(0);
    }

    private void iniciarJuego() {
        if(!jFormattedTextField1.getText().isEmpty())
        {
            juego.setNNave(nNave);
            juego.reset(true);
            this.setVisible(false);
        }
    }

    private void setNNave(int n)
    {
        nNave=n;
        if(n==0) setEstado("I I I I I I I I I I","I I I I I","I I I I I I I");
        if(n==1) setEstado("I I I I I I ","I I I I I ","I I I I I I I I I I");
        if(n==2) setEstado("I I I I I I ","I I I I I I I I I I","I I I I I I");
    }

    private void setEstado(String a, String b, String c)
    {
        velocidad.setText(a);
        poder.setText(b);
        disparo.setText(c);
    }
}
